package LogAccountTest;

import java.awt.List.*;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
import java.util.Arrays;
import java.util.List;

public class LogAccountfuncTest {


	public String InputS(String input) {
		String exitmsg = "0";
		String user_typed = input;

		if (user_typed.equals(exitmsg)){
			exits();
			return null;
		}
		else
			return user_typed;
	}
	
	public void exits() {
		System.out.println("Program will be closed >_<!!");
		System.exit(0);
	}
	
	public void checkChange(String input) throws IOException {
		File file = new File("id.txt");
		FileWriter writer = new FileWriter(file, false);
		writer.write(input);
		writer.close();
	}
}