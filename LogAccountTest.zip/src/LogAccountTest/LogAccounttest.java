package LogAccountTest;

import static org.junit.Assert.*;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import org.junit.Test;

public class LogAccounttest {
	@Test
	public void testInputS() {
		LogAccountfuncTest nullInputTest = new LogAccountfuncTest();
		assertEquals("1234", nullInputTest.InputS("1234"));
	}
	
	@Test
	public void testChgeID() throws IOException {
		LogAccountfuncTest chgeIDTest = new LogAccountfuncTest();
		chgeIDTest.checkChange("1234");
		BufferedReader reader = new BufferedReader(new FileReader("id.txt"));
		assertTrue("1234".equals(reader.readLine()));
	}
}
