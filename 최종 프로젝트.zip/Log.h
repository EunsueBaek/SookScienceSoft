#include <string.h>
#include <stdlib.h>
char ID[11];
char Pswd[11];
char user_typed[11];

void Login();
void Logout();
char* InputS();
int Check(char* a, char* b);