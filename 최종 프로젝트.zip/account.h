#include <string.h>
#include <stdlib.h>

void AccUpdate();
char * Input();
void ChgeID();
void ChgePswd();
void JobPerformAtAccUpdate(int jobnum);
char user_typed2[11];
