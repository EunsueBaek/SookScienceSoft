#include <stdlib.h>

void start();
void exits();