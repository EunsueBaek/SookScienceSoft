#include <stdio.h>
#include "start.h"

void start(){
	printf("WELCOME SCHEDULE MANAGER!\n");
	Login();
}

void exits(){
	printf("Program will be closed>_<!!\n");
	exit(0);
}