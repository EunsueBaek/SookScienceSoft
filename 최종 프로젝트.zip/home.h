void ViewHome(char* id);
void JobPerformAtHome(int jobnumber);