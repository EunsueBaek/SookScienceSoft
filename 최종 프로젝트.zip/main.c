#include <stdio.h>
#include "start.h"
#include "home.h"
#include "Log.h"
#include "account.h"

main(){
	char* id;
	start();
}
